import React, { useState, useContext, useEffect, useRef } from 'react';
import { FiLogIn, FiKey } from 'react-icons/fi';
import logo from '../logo.png';
import { AuthContext } from '../services/context/authContext'
import '../assets/pagesStyles/LoginPage.css';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const [pin, setPin] = useState(['', '', '', '', '']);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const inputRefs = useRef([]);
  const PIN_LENGTH = 5;

  // Auto-focus first input on load
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  // Auto-submit when PIN is complete
  useEffect(() => {
    const fullPin = pin.join('');
    if (fullPin.length === PIN_LENGTH && !isLoading) {
      handleSubmit(new Event('auto-submit'));
    }
  }, [pin]);

  const handleSubmit = async (e) => {
    if (e && e.type !== 'auto-submit') {
      e.preventDefault();
    }
    
    const fullPin = pin.join('');
    if (fullPin.length !== PIN_LENGTH) return;
    
    setIsLoading(true);
    setError('');

    try {
      await login(fullPin);
      navigate('/');
    } catch (err) {
      setError(err.message || 'Invalid PIN. Please try again.');
      setPin(['', '', '', '', '']); // Clear PIN on error
      // Focus first input
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinChange = (index, value) => {
    // Only allow single digit
    if (value.length > 1) return;
    
    // Only allow numeric values
    if (!/^\d*$/.test(value)) return;

    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);

    // Auto-focus next input
    if (value && index < PIN_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
    
    // Auto-login when PIN is complete
    const pinString = newPin.join('');
    if (pinString.length === PIN_LENGTH && !isLoading) {
      handleSubmit(new Event('submit'));
    }
  };

  const handleKeyDown = (index, e) => {
    // Handle backspace - go to previous input
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').trim();
    if (!/^\d+$/.test(pastedData)) return;
    
    const digits = pastedData.slice(0, PIN_LENGTH).split('');
    const newPin = [...pin];
    
    digits.forEach((digit, i) => {
      if (i < PIN_LENGTH) {
        newPin[i] = digit;
      }
    });
    
    setPin(newPin);
    
    // Focus last filled input or first empty
    const lastFilledIndex = Math.min(digits.length, PIN_LENGTH - 1);
    inputRefs.current[lastFilledIndex]?.focus();
  };

  // Handle number pad clicks
  const handleNumberPad = (num) => {
    if (isLoading) return;
    
    // Find first empty slot
    const firstEmptyIndex = pin.findIndex(p => p === '');
    if (firstEmptyIndex === -1) return; // All filled
    
    const newPin = [...pin];
    newPin[firstEmptyIndex] = num;
    setPin(newPin);
    
    // Auto-focus next input
    if (firstEmptyIndex < PIN_LENGTH - 1) {
      inputRefs.current[firstEmptyIndex + 1]?.focus();
    }
    
    // Auto-login when PIN is complete
    const pinString = newPin.join('');
    if (pinString.length === PIN_LENGTH) {
      handleSubmit(new Event('submit'));
    }
  };

  // Handle clear/backspace from keypad
  const handleKeypadBackspace = () => {
    // Find last filled slot
    const lastFilledIndex = pin.findLastIndex(p => p !== '');
    if (lastFilledIndex === -1) return; // All empty
    
    const newPin = [...pin];
    newPin[lastFilledIndex] = '';
    setPin(newPin);
    
    // Focus the cleared input
    inputRefs.current[lastFilledIndex]?.focus();
  };

  const handleKeypadClear = () => {
    setPin(['', '', '', '', '']);
    inputRefs.current[0]?.focus();
  };


  return (
    <div className="stockmaster-login-page">
      <div className="stockmaster-login-container">
        <div className="stockmaster-login-branding">
          <div className="stockmaster-logo">
            <img src={logo} alt="Logo" className="login-logo-png" />
            <h1>POS</h1>
          </div>
          <p className="stockmaster-tagline">DecodeX POS</p>
          <div className="stockmaster-branding-footer">
            <p>© {new Date().getFullYear()}  DecodeX</p>
            <p>v0.0.1</p>
          </div>
        </div>

        <div className="stockmaster-login-form-container">
          <div className="stockmaster-login-card">
            <h2>Welcome Back</h2>
            {error && <div className="stockmaster-error-message">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="stockmaster-form-group">
                <label htmlFor="pin">Enter PIN</label>
                <div className="pin-input-container" onPaste={handlePaste}>
                  {pin.map((digit, index) => (
                    <input
                      key={index}
                      ref={el => inputRefs.current[index] = el}
                      type="password"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handlePinChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      className={`pin-box ${digit ? 'filled' : ''} ${error ? 'error' : ''}`}
                      disabled={isLoading}
                      autoFocus={index === 0}
                    />
                  ))}
                </div>
                {error && <div className="pin-error-message">{error}</div>}
              </div>

              {/* Onscreen Number Pad for Touchscreen */}
              <div className="numpad-container">
                <div className="numpad">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <button
                      key={num}
                      type="button"
                      className="numpad-btn"
                      onClick={() => handleNumberPad(num.toString())}
                      disabled={isLoading}
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    className="numpad-btn numpad-btn-clear"
                    onClick={handleKeypadClear}
                    disabled={isLoading}
                  >
                    C
                  </button>
                  <button
                    type="button"
                    className="numpad-btn"
                    onClick={() => handleNumberPad('0')}
                    disabled={isLoading}
                  >
                    0
                  </button>
                  <button
                    type="button"
                    className="numpad-btn numpad-btn-backspace"
                    onClick={handleKeypadBackspace}
                    disabled={isLoading}
                  >
                    ⌫
                  </button>
                </div>
              </div>
            </form>

            <div className="stockmaster-login-footer">
              <p>
                <a href="/request-access">Request access</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;